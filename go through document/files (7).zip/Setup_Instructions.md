# 📄 Sales Order to PDF - Complete Setup Guide

## Overview
This solution converts your Sales Order data from Google Sheets into a professional PDF invoice matching your exact format.

---

## 🚀 Quick Setup (15 minutes)

### Step 1: Create Google Sheet

1. **Create a new Google Sheet**
   - Go to https://sheets.google.com
   - Click "+ Blank" to create new sheet
   - Name it: "Sales Order Management"

2. **Open Apps Script Editor**
   - In your sheet, click: `Extensions` > `Apps Script`
   - Delete any default code
   - Copy the entire code from `SalesOrder_PDF_Generator.js`
   - Paste it into the script editor
   - Click `Save` (💾 icon)
   - Name the project: "PDF Generator"

### Step 2: Upload Logo to Google Drive

1. **Upload logo.png**
   - Go to https://drive.google.com
   - Click `+ New` > `File upload`
   - Select your `logo.png` file
   - Wait for upload to complete

2. **Get Logo File ID**
   - Right-click on the uploaded logo
   - Click `Get link`
   - Copy the file ID from the URL
   
   Example URL: `https://drive.google.com/file/d/1ABC123xyz456/view`
   
   File ID is: `1ABC123xyz456`

3. **Update Script with Logo ID**
   - Go back to Apps Script editor
   - Find this line (around line 20):
     ```javascript
     LOGO_FILE_ID: 'YOUR_LOGO_FILE_ID',
     ```
   - Replace `'YOUR_LOGO_FILE_ID'` with your actual ID:
     ```javascript
     LOGO_FILE_ID: '1ABC123xyz456',
     ```
   - Click `Save`

### Step 3: Run Setup Function

1. **Select setup function**
   - In Apps Script editor, find the dropdown at top (says "Select function")
   - Select: `setup`

2. **Run the function**
   - Click `Run` (▶️ button)
   - **First time**: You'll see "Authorization required"
     - Click `Review permissions`
     - Choose your Google account
     - Click `Advanced` > `Go to PDF Generator (unsafe)`
     - Click `Allow`

3. **Setup complete!**
   - You'll see a success message with your Output Folder ID
   - Copy this ID

4. **Update Output Folder ID**
   - Find this line in the script:
     ```javascript
     OUTPUT_FOLDER_ID: 'YOUR_OUTPUT_FOLDER_ID',
     ```
   - Replace with your folder ID
   - Click `Save`

### Step 4: Fill in Your Data

**Go back to your Google Sheet. You'll now see 4 new sheets:**

#### 📊 Sheet 1: Sales Orders
This is your main data sheet with columns:

| Invoice No | Invoice Date | Reverse Charge | Transport Mode | Vehicle No | LR No | LR Date | Buyer ID | Ship To ID | ... |
|------------|--------------|----------------|----------------|------------|-------|---------|----------|------------|-----|

**Example row:**
```
RTW/D/26/619 | 29/12/2025 | No | Road | MH-09-XX-1234 | 20781 | 29/12/2025 | B001 | B001 | ...
```

#### 📦 Sheet 2: Order Items
Enter your items here:

| Invoice No | Description | HSN Code | From Order No | To Order No | Pieces | Quantity | UOM | Rate |
|------------|-------------|----------|---------------|-------------|--------|----------|-----|------|

**Example row:**
```
RTW/D/26/619 | DORIA SHIRTINGS | 520812 | RTWAF26-1770 | RTWAF26-1773 | 12 | 1310.70 | MTR | 64.50
```

#### 👥 Sheet 3: Buyers
Store buyer/customer information:

| Buyer ID | Name | Address | City | State | Pincode | GST No | Place |
|----------|------|---------|------|-------|---------|--------|-------|

**Example row:**
```
B001 | MAHAN COTSIN PVT LTD | PLOT NO - 6, G - 4/2, MIDC | TARAPUR INDUSTRIAL AREA | MAHARASHTRA-27 | 401506 | 27AAFCM0378K1Z7 | BHOISAN
```

#### ⚙️ Sheet 4: Settings
Auto-created with your configuration.

---

## 📝 How to Use

### Generate PDF for a Sales Order

1. **Select an order**
   - Go to "Sales Orders" sheet
   - Click on any row with order data (row 2 or below)

2. **Generate PDF**
   - Click the menu: `📄 PDF Generator` > `Generate Invoice PDF`
   - Wait a few seconds
   - Success dialog will appear!

3. **View/Download PDF**
   - Click "Yes" to open the PDF
   - Or click: `📄 PDF Generator` > `📁 Open PDF Folder`

---

## 🎯 Sample Data to Test

Copy this sample data to test the system:

### Sales Orders Sheet:
```
RTW/D/26/619 | 29/12/2025 | No | SHRI DATTA CARRYING CORPORATION | MH-09-1234 | 20781 | 29/12/2025 | B001 | B001 | MAHARASHTRA | SURENDRA S DAMANI | 9876543210 | D26-671 | RTW/D/25-26/D-0280 | GPI/10307/26 | D26-671 | 321423074960458d3ba616a813071790606585813... | 2025-12-29 18:02:00 | CGST/SGST
```

### Order Items Sheet:
```
RTW/D/26/619 | DORIA SHIRTINGS | 520812 | RTWAF26-1770 | RTWAF26-1773 | 12 | 1310.70 | MTR | 64.50
```

### Buyers Sheet:
```
B001 | MAHAN COTSIN PVT LTD | PLOT NO - 6, G - 4/2, MIDC, TARAPUR INDUSTRIAL AREA | BHOISAN | MAHARASHTRA-27 | 401506 | 27AAFCM0378K1Z7 | BHOISAN
```

---

## 🎨 Customization

### Update Company Details

In the script, find the `CONFIG.COMPANY` section and update:

```javascript
COMPANY: {
  name: 'YOUR COMPANY NAME',
  address: 'YOUR ADDRESS',
  pincode: 'YOUR PINCODE',
  phone: 'Tel: YOUR PHONE',
  website: 'Web: YOUR WEBSITE',
  msme: 'MSME No: YOUR MSME NUMBER',
  gst: 'GST NO - YOUR GST NUMBER'
}
```

### Update Bank Details

Find `CONFIG.BANK` and update:

```javascript
BANK: {
  name: 'YOUR BANK NAME',
  accountNo: 'YOUR ACCOUNT NUMBER',
  branch: 'BRANCH CODE',
  ifsc: 'YOUR IFSC CODE'
}
```

### Customize GST Rates

Find the `calculateTotals` function and modify:

```javascript
var gstRate = 5; // Change to your GST rate (e.g., 12, 18, 28)
```

---

## 🔧 Troubleshooting

### Problem: "Logo not found" error
**Solution:** 
- Make sure logo is uploaded to Google Drive
- Logo file ID is correctly set in CONFIG.LOGO_FILE_ID
- Logo file is not in trash
- You have access to the logo file

### Problem: "Authorization required" keeps appearing
**Solution:**
- Complete the authorization process fully
- Make sure you clicked "Allow" (not "Deny")
- Try logging out and back into Google

### Problem: PDF looks different from expected
**Solution:**
- Google Docs has formatting limitations
- Check that all data is properly filled
- Verify special characters display correctly

### Problem: "Cannot find buyer" error
**Solution:**
- Make sure Buyer ID in Sales Orders matches exactly with Buyer ID in Buyers sheet
- IDs are case-sensitive (B001 ≠ b001)

### Problem: PDF not generating
**Solution:**
- Check Browser Console: View > Execution log
- Make sure all required fields have data
- Check for errors in red

### Problem: Numbers not formatting correctly
**Solution:**
- Make sure numeric columns contain numbers only
- No special characters in number fields
- Use decimal point (.) not comma (,)

---

## 📊 Data Format Guidelines

### Dates
- Format: DD/MM/YYYY or use Google Sheets date format
- Example: 29/12/2025

### Numbers
- Quantity: Use decimals (1310.70)
- Rate: Use decimals (64.50)
- Don't use commas in input (Excel will format for display)

### Text
- Keep descriptions concise
- Avoid special characters: &, <, >
- Use CAPS for consistency

### IDs
- Use consistent format (B001, B002, etc.)
- Case-sensitive
- No spaces

---

## 🎓 Advanced Features

### Auto-Calculate GST

The script automatically calculates:
- ✅ CGST + SGST (for same state)
- ✅ IGST (for different state)
- ✅ Total amount
- ✅ Amount in words (Indian numbering)

### Batch PDF Generation

To generate multiple PDFs at once, you can modify the script or run it in a loop.

### Email PDF Automatically

Add this function to email PDFs:

```javascript
function emailPDF(pdfFile, recipientEmail) {
  MailApp.sendEmail({
    to: recipientEmail,
    subject: 'Invoice: ' + orderData.invoiceNo,
    body: 'Please find attached invoice.',
    attachments: [pdfFile.getAs(MimeType.PDF)]
  });
}
```

---

## 📱 Mobile Access

### Generate PDF from Phone

1. Install Google Sheets app
2. Open your spreadsheet
3. Select order row
4. Tap ⋮ (three dots) > "PDF Generator" menu
5. Tap "Generate Invoice PDF"

---

## 🔐 Security & Privacy

### Data Security
- All data stays in your Google account
- Only you have access (unless you share)
- PDFs saved to your Google Drive

### Sharing Access
- Share spreadsheet: File > Share
- Give "Editor" access to allow PDF generation
- Give "Viewer" access for read-only

---

## 💾 Backup

### Export Backup
1. File > Download > Microsoft Excel
2. Saves all sheets as .xlsx

### Restore from Backup
1. File > Import
2. Select your .xlsx file
3. Choose "Replace spreadsheet"

---

## 🆘 Support

### Getting Help

1. **Check Execution Log**
   - Apps Script Editor > View > Execution log
   - Look for error messages

2. **Common Error Messages**
   - "Cannot read property" → Missing data
   - "File not found" → Wrong ID
   - "Permission denied" → Re-authorize

3. **Test with Sample Data**
   - Use the sample data provided above
   - If it works, your data format needs adjustment

---

## ✅ Checklist

Before generating your first PDF:

- [ ] Apps Script code pasted and saved
- [ ] Logo uploaded to Drive
- [ ] Logo File ID updated in CONFIG
- [ ] setup() function run successfully
- [ ] Output Folder ID updated in CONFIG
- [ ] Company details updated
- [ ] Bank details updated
- [ ] Sample data added to all sheets
- [ ] Test PDF generated successfully
- [ ] Real data entered
- [ ] Production PDF generated

---

## 🎉 You're Done!

Your Sales Order to PDF system is now ready!

**Quick Reference:**
1. Enter order in "Sales Orders" sheet
2. Add items in "Order Items" sheet
3. Select order row
4. Click: PDF Generator > Generate Invoice PDF
5. Download from PDF folder!

---

## 📞 Additional Customization Requests

If you need:
- Different layout
- Additional fields
- Email integration
- Multiple templates
- Custom calculations
- Automated workflows

Feel free to modify the script or ask for help!

---

**Version:** 1.0  
**Last Updated:** January 2025  
**Author:** Custom Solution for Ramratan Techno Weave
