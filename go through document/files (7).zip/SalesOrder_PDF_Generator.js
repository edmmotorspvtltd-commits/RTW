/**
 * ================================================================
 * RAMRATAN TECHNO WEAVE - SALES ORDER TO PDF GENERATOR
 * ================================================================
 * This script converts Sales Order data to PDF matching your invoice format
 * 
 * SETUP INSTRUCTIONS:
 * 1. Create a Google Sheet with your sales order data
 * 2. Upload logo.png to Google Drive
 * 3. Create necessary sheets (see structure below)
 * 4. Copy this code to Script Editor (Extensions > Apps Script)
 * 5. Run setup() function once
 * 6. Click "Generate PDF" button in your sheet
 * ================================================================
 */

// ==================== CONFIGURATION ====================
var CONFIG = {
  // Update these IDs after setup
  LOGO_FILE_ID: 'YOUR_LOGO_FILE_ID', // Upload logo.png to Drive and paste ID here
  OUTPUT_FOLDER_ID: 'YOUR_OUTPUT_FOLDER_ID', // Folder where PDFs will be saved
  
  // Company Details (Update with your info)
  COMPANY: {
    name: 'RAMRATAN TECHNO WEAVE',
    address: 'GAT NO 294, BUNG-24, BUNG-1770-1, NEAR SOMANI OIL GAS, SAVADI MALA, SHAHAD-5, ICHALKARANJI',
    pincode: '416115, Dist: KOLHAPUR',
    phone: 'Tel: 9422855123',
    website: 'Web: WWW.RAMRATANTEXTILES.COM',
    msme: 'MSME No: UDYAM-MH-13-0074949 | MSME Type: Micro',
    gst: 'GST NO - 27AAFFR8063A2ZA'
  },
  
  // Bank Details
  BANK: {
    name: 'MAHARASHTRA GRAMIN BANK LTD',
    accountNo: '01213010000120',
    branch: 'MSBL0000012',
    ifsc: 'MSBL0000012'
  },
  
  // Sheet Names
  SHEETS: {
    ORDERS: 'Sales Orders',
    ITEMS: 'Order Items',
    BUYERS: 'Buyers',
    SETTINGS: 'Settings'
  }
};

// ==================== MAIN FUNCTIONS ====================

/**
 * Creates custom menu when spreadsheet opens
 */
function onOpen() {
  var ui = SpreadsheetApp.getUi();
  ui.createMenu('📄 PDF Generator')
    .addItem('Generate Invoice PDF', 'generateInvoicePDF')
    .addSeparator()
    .addItem('⚙️ Setup', 'showSetupDialog')
    .addItem('📁 Open PDF Folder', 'openPDFFolder')
    .addToUi();
}

/**
 * Setup function - Run this ONCE after pasting code
 */
function setup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  
  // Create necessary sheets if they don't exist
  createSheetIfNotExists(ss, CONFIG.SHEETS.ORDERS);
  createSheetIfNotExists(ss, CONFIG.SHEETS.ITEMS);
  createSheetIfNotExists(ss, CONFIG.SHEETS.BUYERS);
  createSheetIfNotExists(ss, CONFIG.SHEETS.SETTINGS);
  
  // Setup headers
  setupOrdersSheet(ss);
  setupItemsSheet(ss);
  setupBuyersSheet(ss);
  setupSettingsSheet(ss);
  
  // Create output folder
  var folder = DriveApp.createFolder('Sales Order PDFs - ' + new Date().getTime());
  CONFIG.OUTPUT_FOLDER_ID = folder.getId();
  
  SpreadsheetApp.getUi().alert(
    'Setup Complete!\n\n' +
    'PDF Output Folder ID: ' + folder.getId() + '\n\n' +
    'Next Steps:\n' +
    '1. Upload logo.png to Google Drive\n' +
    '2. Update CONFIG.LOGO_FILE_ID in the code\n' +
    '3. Update CONFIG.OUTPUT_FOLDER_ID with: ' + folder.getId()
  );
}

/**
 * Main function to generate invoice PDF
 */
function generateInvoicePDF() {
  try {
    var ss = SpreadsheetApp.getActiveSpreadsheet();
    var ordersSheet = ss.getSheetByName(CONFIG.SHEETS.ORDERS);
    
    // Get active row
    var activeRow = ordersSheet.getActiveRange().getRow();
    
    if (activeRow < 2) {
      SpreadsheetApp.getUi().alert('Please select a sales order row first!');
      return;
    }
    
    // Get order data
    var orderData = getOrderData(activeRow);
    
    if (!orderData) {
      SpreadsheetApp.getUi().alert('No data found for selected order!');
      return;
    }
    
    // Generate PDF
    var pdfFile = createInvoicePDF(orderData);
    
    // Show success message
    var ui = SpreadsheetApp.getUi();
    var response = ui.alert(
      'PDF Generated Successfully!',
      'Invoice: ' + orderData.invoiceNo + '\n' +
      'File: ' + pdfFile.getName() + '\n\n' +
      'Would you like to open the PDF?',
      ui.ButtonSet.YES_NO
    );
    
    if (response == ui.Button.YES) {
      var htmlOutput = HtmlService.createHtmlOutput(
        '<script>window.open("' + pdfFile.getUrl() + '", "_blank");</script>'
      );
      SpreadsheetApp.getUi().showModalDialog(htmlOutput, 'Opening PDF...');
    }
    
  } catch (error) {
    SpreadsheetApp.getUi().alert('Error: ' + error.toString());
    Logger.log('Error in generateInvoicePDF: ' + error);
  }
}

/**
 * Get order data from sheets
 */
function getOrderData(row) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var ordersSheet = ss.getSheetByName(CONFIG.SHEETS.ORDERS);
  var itemsSheet = ss.getSheetByName(CONFIG.SHEETS.ITEMS);
  var buyersSheet = ss.getSheetByName(CONFIG.SHEETS.BUYERS);
  
  // Get order header data
  var orderRow = ordersSheet.getRange(row, 1, 1, 20).getValues()[0];
  
  var orderData = {
    invoiceNo: orderRow[0] || '',
    invoiceDate: formatDate(orderRow[1]),
    isReverseCharge: orderRow[2] || 'No',
    transportMode: orderRow[3] || '',
    vehicleNo: orderRow[4] || '',
    lrNo: orderRow[5] || '',
    lrDate: formatDate(orderRow[6]),
    buyerId: orderRow[7] || '',
    shipToId: orderRow[8] || '',
    placeOfSupply: orderRow[9] || '',
    agentName: orderRow[10] || '',
    agentMobile: orderRow[11] || '',
    eWayBill: orderRow[12] || '',
    saleContractNo: orderRow[13] || '',
    partyContractNo: orderRow[14] || '',
    challanNo: orderRow[15] || '',
    eInvoiceNo: orderRow[16] || '',
    ackDate: formatDate(orderRow[17]),
    gstType: orderRow[18] || 'CGST/SGST', // CGST/SGST or IGST
    items: [],
    buyer: {},
    shipTo: {}
  };
  
  // Get buyer details
  orderData.buyer = getBuyerDetails(buyersSheet, orderData.buyerId);
  orderData.shipTo = getBuyerDetails(buyersSheet, orderData.shipToId);
  
  // Get items
  orderData.items = getOrderItems(itemsSheet, orderData.invoiceNo);
  
  // Calculate totals
  calculateTotals(orderData);
  
  return orderData;
}

/**
 * Get buyer details by ID
 */
function getBuyerDetails(buyersSheet, buyerId) {
  var data = buyersSheet.getDataRange().getValues();
  
  for (var i = 1; i < data.length; i++) {
    if (data[i][0] == buyerId) {
      return {
        name: data[i][1] || '',
        address: data[i][2] || '',
        city: data[i][3] || '',
        state: data[i][4] || '',
        pincode: data[i][5] || '',
        gstNo: data[i][6] || '',
        place: data[i][7] || ''
      };
    }
  }
  
  return {
    name: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
    gstNo: '',
    place: ''
  };
}

/**
 * Get order items
 */
function getOrderItems(itemsSheet, invoiceNo) {
  var data = itemsSheet.getDataRange().getValues();
  var items = [];
  
  for (var i = 1; i < data.length; i++) {
    if (data[i][0] == invoiceNo) {
      items.push({
        srNo: items.length + 1,
        description: data[i][1] || '',
        hsnCode: data[i][2] || '',
        fromOrderNo: data[i][3] || '',
        toOrderNo: data[i][4] || '',
        pieces: parseFloat(data[i][5]) || 0,
        quantity: parseFloat(data[i][6]) || 0,
        uom: data[i][7] || 'MTR',
        rate: parseFloat(data[i][8]) || 0,
        amount: 0 // Will be calculated
      });
    }
  }
  
  // Calculate amounts
  items.forEach(function(item) {
    item.amount = item.quantity * item.rate;
  });
  
  return items;
}

/**
 * Calculate totals including GST
 */
function calculateTotals(orderData) {
  var totalAmount = 0;
  
  orderData.items.forEach(function(item) {
    totalAmount += item.amount;
  });
  
  orderData.totalAmount = totalAmount;
  
  // Assuming 2.5% CGST + 2.5% SGST or 5% IGST
  var gstRate = 5; // Total GST %
  
  if (orderData.gstType === 'IGST') {
    orderData.igst = (totalAmount * gstRate) / 100;
    orderData.cgst = 0;
    orderData.sgst = 0;
  } else {
    orderData.cgst = (totalAmount * (gstRate/2)) / 100;
    orderData.sgst = (totalAmount * (gstRate/2)) / 100;
    orderData.igst = 0;
  }
  
  orderData.grandTotal = totalAmount + orderData.cgst + orderData.sgst + orderData.igst;
  orderData.tcsAmount = 0.09; // As per your invoice
  orderData.finalTotal = orderData.grandTotal + orderData.tcsAmount;
  
  // Convert amount to words
  orderData.amountInWords = convertNumberToWords(Math.round(orderData.finalTotal));
}

/**
 * Create Invoice PDF
 */
function createInvoicePDF(orderData) {
  // Create a new Google Doc
  var doc = DocumentApp.create('Invoice_' + orderData.invoiceNo + '_' + new Date().getTime());
  var body = doc.getBody();
  
  // Clear default content
  body.clear();
  
  // Set page margins (in points)
  body.setMarginTop(36);    // 0.5 inch
  body.setMarginBottom(36);
  body.setMarginLeft(36);
  body.setMarginRight(36);
  
  // Build the invoice
  buildInvoiceHeader(body, orderData);
  body.appendParagraph(''); // Spacing
  
  buildInvoiceDetails(body, orderData);
  body.appendParagraph(''); // Spacing
  
  buildBuyerDetails(body, orderData);
  body.appendParagraph(''); // Spacing
  
  buildItemsTable(body, orderData);
  body.appendParagraph(''); // Spacing
  
  buildTotalsSection(body, orderData);
  body.appendParagraph(''); // Spacing
  
  buildBankDetails(body, orderData);
  body.appendParagraph(''); // Spacing
  
  buildFooter(body, orderData);
  
  // Save and close
  doc.saveAndClose();
  
  // Convert to PDF
  var docFile = DriveApp.getFileById(doc.getId());
  var pdfBlob = docFile.getAs('application/pdf');
  pdfBlob.setName('Invoice_' + orderData.invoiceNo + '.pdf');
  
  // Save to output folder
  var folder = DriveApp.getFolderById(CONFIG.OUTPUT_FOLDER_ID);
  var pdfFile = folder.createFile(pdfBlob);
  
  // Delete temporary doc
  docFile.setTrashed(true);
  
  return pdfFile;
}

/**
 * Build invoice header with logo and company details
 */
function buildInvoiceHeader(body, orderData) {
  var headerTable = body.appendTable();
  var headerRow = headerTable.appendTableRow();
  
  // Left cell - Logo and company details
  var leftCell = headerRow.appendTableCell();
  
  // Add logo if available
  try {
    if (CONFIG.LOGO_FILE_ID && CONFIG.LOGO_FILE_ID !== 'YOUR_LOGO_FILE_ID') {
      var logoFile = DriveApp.getFileById(CONFIG.LOGO_FILE_ID);
      var logoBlob = logoFile.getBlob();
      var logo = leftCell.appendImage(logoBlob);
      logo.setWidth(120);
      logo.setHeight(40);
    }
  } catch(e) {
    Logger.log('Logo not found: ' + e);
  }
  
  // Company name
  var companyName = leftCell.appendParagraph(CONFIG.COMPANY.name);
  companyName.setHeading(DocumentApp.ParagraphHeading.HEADING1);
  companyName.setBold(true);
  
  // Company details
  var address = leftCell.appendParagraph(CONFIG.COMPANY.address);
  address.editAsText().setFontSize(9);
  
  var pincode = leftCell.appendParagraph(CONFIG.COMPANY.pincode);
  pincode.editAsText().setFontSize(9);
  
  var contact = leftCell.appendParagraph(CONFIG.COMPANY.phone);
  contact.editAsText().setFontSize(9);
  
  var website = leftCell.appendParagraph(CONFIG.COMPANY.website);
  website.editAsText().setFontSize(9);
  
  var msme = leftCell.appendParagraph(CONFIG.COMPANY.msme);
  msme.editAsText().setFontSize(8);
  
  // Right cell - GST and heading
  var rightCell = headerRow.appendTableCell();
  rightCell.setVerticalAlignment(DocumentApp.VerticalAlignment.TOP);
  
  var gst = rightCell.appendParagraph(CONFIG.COMPANY.gst);
  gst.editAsText().setFontSize(10).setBold(true);
  gst.setAlignment(DocumentApp.HorizontalAlignment.RIGHT);
  
  rightCell.appendParagraph(''); // Spacing
  
  var taxInvoice = rightCell.appendParagraph('TAX INVOICE');
  taxInvoice.setHeading(DocumentApp.ParagraphHeading.HEADING2);
  taxInvoice.setBold(true);
  taxInvoice.setAlignment(DocumentApp.HorizontalAlignment.RIGHT);
  
  // Table styling
  headerTable.setBorderWidth(0);
}

/**
 * Build invoice details section
 */
function buildInvoiceDetails(body, orderData) {
  var detailsTable = body.appendTable();
  var row1 = detailsTable.appendTableRow();
  
  // Left column
  var leftCell = row1.appendTableCell();
  addLabelValue(leftCell, 'Invoice No.', orderData.invoiceNo);
  addLabelValue(leftCell, 'Invoice Date', orderData.invoiceDate);
  addLabelValue(leftCell, 'Is This Reverse Charge Invoice', orderData.isReverseCharge);
  
  // Right column
  var rightCell = row1.appendTableCell();
  addLabelValue(rightCell, 'Transport', orderData.transportMode);
  addLabelValue(rightCell, '', ''); // SHRI DATTA CARRYING CORPORATION
  addLabelValue(rightCell, 'Vehicle No', orderData.vehicleNo);
  addLabelValue(rightCell, 'LR No.', orderData.lrNo);
  addLabelValue(rightCell, 'LR Date', orderData.lrDate);
  
  detailsTable.setBorderWidth(1);
}

/**
 * Build buyer and ship-to details
 */
function buildBuyerDetails(body, orderData) {
  var buyerTable = body.appendTable();
  var row = buyerTable.appendTableRow();
  
  // Invoice To
  var invoiceToCell = row.appendTableCell();
  var invoiceToHeader = invoiceToCell.appendParagraph('Invoice To:');
  invoiceToHeader.setBold(true);
  
  invoiceToCell.appendParagraph(orderData.buyer.name);
  invoiceToCell.appendParagraph(orderData.buyer.address);
  invoiceToCell.appendParagraph(orderData.buyer.city);
  invoiceToCell.appendParagraph('Pin Code: ' + orderData.buyer.pincode);
  
  var placeLabel = invoiceToCell.appendParagraph('');
  addInlineLabelValue(placeLabel, 'Place', orderData.buyer.place);
  
  var gstLabel = invoiceToCell.appendParagraph('');
  addInlineLabelValue(gstLabel, 'GST No', orderData.buyer.gstNo);
  
  var stateLabel = invoiceToCell.appendParagraph('');
  addInlineLabelValue(stateLabel, 'State', orderData.buyer.state);
  
  // Ship To
  var shipToCell = row.appendTableCell();
  var shipToHeader = shipToCell.appendParagraph('Ship To:');
  shipToHeader.setBold(true);
  
  shipToCell.appendParagraph(orderData.shipTo.name);
  shipToCell.appendParagraph(orderData.shipTo.address);
  shipToCell.appendParagraph(orderData.shipTo.city + ' - ' + orderData.shipTo.state);
  shipToCell.appendParagraph('Pin Code: ' + orderData.shipTo.pincode);
  
  var shipPlaceLabel = shipToCell.appendParagraph('');
  addInlineLabelValue(shipPlaceLabel, 'Place', orderData.shipTo.place);
  
  var shipGstLabel = shipToCell.appendParagraph('');
  addInlineLabelValue(shipGstLabel, 'GST No', orderData.shipTo.gstNo);
  
  var saleContLabel = shipToCell.appendParagraph('');
  addInlineLabelValue(saleContLabel, 'Sale Cont. No.', orderData.saleContractNo);
  
  var partyContLabel = shipToCell.appendParagraph('');
  addInlineLabelValue(partyContLabel, 'Party Cont.', orderData.partyContractNo);
  
  var challanLabel = shipToCell.appendParagraph('');
  addInlineLabelValue(challanLabel, 'Challan No', orderData.challanNo);
  
  buyerTable.setBorderWidth(1);
}

/**
 * Build items table
 */
function buildItemsTable(body, orderData) {
  var itemsTable = body.appendTable();
  
  // Header row
  var headerRow = itemsTable.appendTableRow();
  headerRow.getCell(0).setBackgroundColor('#CCCCCC');
  
  var headers = ['Sr.', 'Description of Goods', 'HSN', 'From To', 'Pieces', 'Quantity', 'UOM', 'Rate', 'Amount'];
  
  headers.forEach(function(header) {
    var cell = headerRow.appendTableCell(header);
    cell.setBackgroundColor('#CCCCCC');
    var para = cell.getChild(0).asParagraph();
    para.setBold(true);
    para.setAlignment(DocumentApp.HorizontalAlignment.CENTER);
    para.editAsText().setFontSize(9);
  });
  
  headerRow.removeChild(headerRow.getCell(0)); // Remove extra first cell
  
  // Data rows
  var totalPieces = 0;
  var totalQuantity = 0;
  
  orderData.items.forEach(function(item) {
    var row = itemsTable.appendTableRow();
    
    row.appendTableCell(item.srNo.toString()).editAsText().setFontSize(9);
    row.appendTableCell(item.description).editAsText().setFontSize(9);
    row.appendTableCell(item.hsnCode).editAsText().setFontSize(9);
    row.appendTableCell(item.fromOrderNo + ' TO ' + item.toOrderNo).editAsText().setFontSize(9);
    row.appendTableCell(item.pieces.toString()).editAsText().setFontSize(9);
    row.appendTableCell(formatNumber(item.quantity, 2)).editAsText().setFontSize(9);
    row.appendTableCell(item.uom).editAsText().setFontSize(9);
    row.appendTableCell(formatNumber(item.rate, 2)).editAsText().setFontSize(9);
    row.appendTableCell(formatNumber(item.amount, 2)).editAsText().setFontSize(9);
    
    totalPieces += item.pieces;
    totalQuantity += item.quantity;
  });
  
  // Total row
  var totalRow = itemsTable.appendTableRow();
  totalRow.appendTableCell('').setBold(true);
  totalRow.appendTableCell('Total').setBold(true).editAsText().setFontSize(9);
  totalRow.appendTableCell('').setBold(true);
  totalRow.appendTableCell('').setBold(true);
  totalRow.appendTableCell(totalPieces.toString()).setBold(true).editAsText().setFontSize(9);
  totalRow.appendTableCell(formatNumber(totalQuantity, 1)).setBold(true).editAsText().setFontSize(9);
  totalRow.appendTableCell('').setBold(true);
  totalRow.appendTableCell('').setBold(true);
  totalRow.appendTableCell(formatNumber(orderData.totalAmount, 2)).setBold(true).editAsText().setFontSize(9);
  
  itemsTable.setBorderWidth(1);
}

/**
 * Build totals section with GST
 */
function buildTotalsSection(body, orderData) {
  var totalsTable = body.appendTable();
  var row = totalsTable.appendTableRow();
  
  // Left cell - Additional/Less Charges
  var leftCell = row.appendTableCell();
  leftCell.appendParagraph('Additional Charges:').editAsText().setBold(true).setFontSize(9);
  leftCell.appendParagraph('Less Charges:').editAsText().setBold(true).setFontSize(9);
  leftCell.appendParagraph('DISCOUNT - 3.00 %-Rs. 2,536.20').editAsText().setFontSize(8);
  leftCell.appendParagraph('BROKERAGE - 1.00 %-Rs. 820.04').editAsText().setFontSize(8);
  
  // Right cell - Tax breakdown
  var rightCell = row.appendTableCell();
  
  var taxTable = rightCell.appendTable();
  
  addTotalRow(taxTable, 'Add', '');
  addTotalRow(taxTable, 'Less', formatNumber(3356.24, 2));
  addTotalRow(taxTable, 'Sub Total', formatNumber(orderData.totalAmount - 3356.24, 2));
  
  if (orderData.gstType === 'IGST') {
    addTotalRow(taxTable, 'I. GST', formatNumber(orderData.igst, 2));
  } else {
    addTotalRow(taxTable, 'C. GST (2.5)%', formatNumber(orderData.cgst, 2));
    addTotalRow(taxTable, 'S. GST (2.5)%', formatNumber(orderData.sgst, 2));
  }
  
  addTotalRow(taxTable, 'Total', formatNumber(orderData.grandTotal, 2));
  addTotalRow(taxTable, 'TCS Amount', formatNumber(orderData.tcsAmount, 2));
  addTotalRow(taxTable, 'R/O', '');
  
  var grandRow = taxTable.appendTableRow();
  var grandLabelCell = grandRow.appendTableCell('Grand Total');
  grandLabelCell.setBold(true);
  grandLabelCell.setBackgroundColor('#CCCCCC');
  var grandValueCell = grandRow.appendTableCell(formatNumber(orderData.finalTotal, 2));
  grandValueCell.setBold(true);
  grandValueCell.setBackgroundColor('#CCCCCC');
  
  taxTable.setBorderWidth(1);
  
  totalsTable.setBorderWidth(1);
}

/**
 * Build bank details section
 */
function buildBankDetails(body, orderData) {
  var bankTable = body.appendTable();
  
  var row1 = bankTable.appendTableRow();
  row1.appendTableCell('Company\'s Bank Details:').setBold(true).editAsText().setFontSize(9);
  
  var row2 = bankTable.appendTableRow();
  var detailsCell = row2.appendTableCell();
  
  addLabelValue(detailsCell, 'Bank Name', CONFIG.BANK.name, 9);
  
  var accountRow = detailsCell.appendParagraph('');
  var accountText = accountRow.editAsText();
  accountText.appendText('A/c No: ').setFontSize(9).setBold(true);
  accountText.appendText(CONFIG.BANK.accountNo).setFontSize(9);
  
  var ifscRow = detailsCell.appendParagraph('');
  var ifscText = ifscRow.editAsText();
  ifscText.appendText('Branch & IFSC Code: ').setFontSize(9).setBold(true);
  ifscText.appendText(CONFIG.BANK.ifsc).setFontSize(9);
  
  var row3 = bankTable.appendTableRow();
  var amountCell = row3.appendTableCell();
  
  var amountLabel = amountCell.appendParagraph('');
  var amountText = amountLabel.editAsText();
  amountText.appendText('Duty Chargeable (in words): ').setFontSize(9).setBold(true);
  amountText.appendText('INR ' + orderData.amountInWords + ' only').setFontSize(9);
  
  var row4 = bankTable.appendTableRow();
  var amountCell2 = row4.appendTableCell();
  
  var amountLabel2 = amountCell2.appendParagraph('');
  var amountText2 = amountLabel2.editAsText();
  amountText2.appendText('Amount Chargeable (in words): ').setFontSize(9).setBold(true);
  amountText2.appendText('INR ' + orderData.amountInWords + ' only').setFontSize(9);
  
  bankTable.setBorderWidth(1);
}

/**
 * Build footer with terms and signature
 */
function buildFooter(body, orderData) {
  var footerTable = body.appendTable();
  
  var row1 = footerTable.appendTableRow();
  var termsCell = row1.appendTableCell('Terms and Condition:');
  termsCell.setBold(true).editAsText().setFontSize(9);
  
  var row2 = footerTable.appendTableRow();
  var termsDetailCell = row2.appendTableCell();
  termsDetailCell.appendParagraph('THE ORIENTAL INSURANCE COMPANY LIMITED - 162002/31/2025/42')
    .editAsText().setFontSize(8);
  
  var row3 = footerTable.appendTableRow();
  var signCell = row3.appendTableCell();
  signCell.appendParagraph('').appendText(' '); // Spacing for signature
  signCell.appendParagraph('').appendText(' '); 
  signCell.appendParagraph('').appendText(' '); 
  
  var sigLine = signCell.appendParagraph('For ' + CONFIG.COMPANY.name);
  sigLine.editAsText().setFontSize(9).setBold(true);
  sigLine.setAlignment(DocumentApp.HorizontalAlignment.RIGHT);
  
  signCell.appendParagraph('').appendText(' '); 
  signCell.appendParagraph('').appendText(' '); 
  
  var authSig = signCell.appendParagraph('Authorised Signatory');
  authSig.editAsText().setFontSize(9);
  authSig.setAlignment(DocumentApp.HorizontalAlignment.RIGHT);
  
  footerTable.setBorderWidth(1);
}

// ==================== HELPER FUNCTIONS ====================

/**
 * Add label-value pair to cell
 */
function addLabelValue(cell, label, value, fontSize) {
  fontSize = fontSize || 10;
  var para = cell.appendParagraph('');
  var text = para.editAsText();
  if (label) {
    text.appendText(label + ': ').setFontSize(fontSize).setBold(true);
  }
  text.appendText(value || '').setFontSize(fontSize);
}

/**
 * Add inline label-value to existing paragraph
 */
function addInlineLabelValue(para, label, value) {
  var text = para.editAsText();
  text.appendText(label + ': ').setFontSize(9).setBold(true);
  text.appendText(value || '').setFontSize(9);
}

/**
 * Add total row to table
 */
function addTotalRow(table, label, value) {
  var row = table.appendTableRow();
  row.appendTableCell(label).editAsText().setFontSize(9);
  row.appendTableCell(value).editAsText().setFontSize(9);
}

/**
 * Format number with Indian numbering system
 */
function formatNumber(num, decimals) {
  if (!num) return '0.00';
  
  var parts = num.toFixed(decimals).toString().split('.');
  var intPart = parts[0];
  var decPart = parts[1];
  
  // Indian numbering: 1,23,456.78
  var lastThree = intPart.substring(intPart.length - 3);
  var otherNumbers = intPart.substring(0, intPart.length - 3);
  
  if (otherNumbers != '') {
    lastThree = ',' + lastThree;
  }
  
  var formatted = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + lastThree;
  
  return decimals > 0 ? formatted + '.' + decPart : formatted;
}

/**
 * Format date
 */
function formatDate(date) {
  if (!date) return '';
  
  if (typeof date === 'string') return date;
  
  var d = new Date(date);
  var day = ('0' + d.getDate()).slice(-2);
  var month = ('0' + (d.getMonth() + 1)).slice(-2);
  var year = d.getFullYear();
  
  return day + '/' + month + '/' + year;
}

/**
 * Convert number to words (Indian system)
 */
function convertNumberToWords(num) {
  if (num === 0) return 'Zero';
  
  var ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  var tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  var teens = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  
  function convertLessThanThousand(n) {
    if (n === 0) return '';
    
    if (n < 10) return ones[n];
    if (n < 20) return teens[n - 10];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + ones[n % 10] : '');
    
    return ones[Math.floor(n / 100)] + ' Hundred' + (n % 100 !== 0 ? ' ' + convertLessThanThousand(n % 100) : '');
  }
  
  if (num < 1000) return convertLessThanThousand(num);
  
  if (num < 100000) {
    return convertLessThanThousand(Math.floor(num / 1000)) + ' Thousand' + 
           (num % 1000 !== 0 ? ' ' + convertLessThanThousand(num % 1000) : '');
  }
  
  if (num < 10000000) {
    return convertLessThanThousand(Math.floor(num / 100000)) + ' Lakh' + 
           (num % 100000 !== 0 ? ' ' + convertNumberToWords(num % 100000) : '');
  }
  
  return convertLessThanThousand(Math.floor(num / 10000000)) + ' Crore' + 
         (num % 10000000 !== 0 ? ' ' + convertNumberToWords(num % 10000000) : '');
}

/**
 * Create sheet if it doesn't exist
 */
function createSheetIfNotExists(ss, sheetName) {
  var sheet = ss.getSheetByName(sheetName);
  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
  }
  return sheet;
}

/**
 * Setup Orders Sheet with headers
 */
function setupOrdersSheet(ss) {
  var sheet = ss.getSheetByName(CONFIG.SHEETS.ORDERS);
  
  var headers = [
    'Invoice No', 'Invoice Date', 'Reverse Charge', 'Transport Mode', 'Vehicle No',
    'LR No', 'LR Date', 'Buyer ID', 'Ship To ID', 'Place of Supply',
    'Agent Name', 'Agent Mobile', 'E-Way Bill', 'Sale Contract No', 'Party Contract No',
    'Challan No', 'E-Invoice No', 'Ack Date', 'GST Type (CGST/SGST or IGST)'
  ];
  
  sheet.getRange(1, 1, 1, headers.length).setValues([headers])
    .setFontWeight('bold')
    .setBackground('#4285F4')
    .setFontColor('#FFFFFF');
  
  sheet.setFrozenRows(1);
  sheet.autoResizeColumns(1, headers.length);
}

/**
 * Setup Items Sheet with headers
 */
function setupItemsSheet(ss) {
  var sheet = ss.getSheetByName(CONFIG.SHEETS.ITEMS);
  
  var headers = [
    'Invoice No', 'Description', 'HSN Code', 'From Order No', 'To Order No',
    'Pieces', 'Quantity', 'UOM', 'Rate'
  ];
  
  sheet.getRange(1, 1, 1, headers.length).setValues([headers])
    .setFontWeight('bold')
    .setBackground('#34A853')
    .setFontColor('#FFFFFF');
  
  sheet.setFrozenRows(1);
  sheet.autoResizeColumns(1, headers.length);
}

/**
 * Setup Buyers Sheet with headers
 */
function setupBuyersSheet(ss) {
  var sheet = ss.getSheetByName(CONFIG.SHEETS.BUYERS);
  
  var headers = [
    'Buyer ID', 'Name', 'Address', 'City', 'State', 'Pincode', 'GST No', 'Place'
  ];
  
  sheet.getRange(1, 1, 1, headers.length).setValues([headers])
    .setFontWeight('bold')
    .setBackground('#FBBC04')
    .setFontColor('#FFFFFF');
  
  sheet.setFrozenRows(1);
  sheet.autoResizeColumns(1, headers.length);
}

/**
 * Setup Settings Sheet
 */
function setupSettingsSheet(ss) {
  var sheet = ss.getSheetByName(CONFIG.SHEETS.SETTINGS);
  
  sheet.getRange('A1').setValue('Logo File ID:');
  sheet.getRange('B1').setValue(CONFIG.LOGO_FILE_ID);
  
  sheet.getRange('A2').setValue('Output Folder ID:');
  sheet.getRange('B2').setValue(CONFIG.OUTPUT_FOLDER_ID);
  
  sheet.getRange('A1:A2').setFontWeight('bold');
}

/**
 * Show setup dialog
 */
function showSetupDialog() {
  var html = '<h2>Setup Instructions</h2>' +
    '<ol>' +
    '<li>Upload your logo.png to Google Drive</li>' +
    '<li>Right-click the logo file > Get link > Copy file ID from URL</li>' +
    '<li>Update CONFIG.LOGO_FILE_ID in the script</li>' +
    '<li>Create a folder for PDFs in Drive</li>' +
    '<li>Update CONFIG.OUTPUT_FOLDER_ID with folder ID</li>' +
    '<li>Fill in your data in the sheets</li>' +
    '</ol>';
  
  var htmlOutput = HtmlService.createHtmlOutput(html)
    .setWidth(400)
    .setHeight(300);
  
  SpreadsheetApp.getUi().showModalDialog(htmlOutput, 'Setup Instructions');
}

/**
 * Open PDF output folder
 */
function openPDFFolder() {
  try {
    var folder = DriveApp.getFolderById(CONFIG.OUTPUT_FOLDER_ID);
    var html = '<script>window.open("' + folder.getUrl() + '", "_blank");</script>';
    var htmlOutput = HtmlService.createHtmlOutput(html);
    SpreadsheetApp.getUi().showModalDialog(htmlOutput, 'Opening folder...');
  } catch(e) {
    SpreadsheetApp.getUi().alert('Please set up OUTPUT_FOLDER_ID first!');
  }
}
